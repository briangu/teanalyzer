class RowsParameters
  attr_accessor :row_1_penalty_bottom, :row_2_penalty_home, :row_3_penalty, :row_4_penalty_top, :penalty_weight
end