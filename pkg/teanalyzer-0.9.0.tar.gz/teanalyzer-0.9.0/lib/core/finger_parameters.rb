class FingerParameters
  attr_accessor :finger_0_penalty, :finger_1_penalty, :finger_2_penalty, :finger_3_penalty, :finger_4_penalty
  attr_accessor :penalty_weight


end